#ifndef UI_H
#define UI_H
#include "aalib.h"
extern aa_context *context;
extern void main_loop(void);
extern void fsave(void);
#endif
