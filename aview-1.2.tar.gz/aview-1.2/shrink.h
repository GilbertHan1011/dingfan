#ifndef SHRINK_H
#define SHRINK_H
extern void shrink(aa_context *, int, int, int, int, int);
#endif
