#ifndef _IMAGE_H
#define _IMAGE_H
extern int imgwidth, imgheight;
extern unsigned char *imgdata;
extern int load_image(char *name);
#endif
